﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController32 : MonoBehaviour
{
    bool isOnGround;

    float speed = 10.0f;
    float gravityModifier = 2.0f;

    float xLimit = 5.0f;
    float zLimit = 30.0f;

    Rigidbody playerRb;

    public GameObject MoveCube;

    // Start is called before the first frame update
    void Start()
    {
        isOnGround = true;
        Physics.gravity *= gravityModifier;

        playerRb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        PlayerMove();
        PlayerJump();
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("HPlayPlane") || collision.gameObject.CompareTag("StartCube") || collision.gameObject.CompareTag("MoveCube"))
        {
            isOnGround = true;
        }
    }

    private void PlayerJump()
    {
        if(Input.GetKeyDown(KeyCode.Space) && isOnGround)
        {
            playerRb.AddForce(Vector3.up * speed, ForceMode.Impulse);
            isOnGround = false;
        }
    }

    private void PlayerMove()
    {
        float inputVertical = Input.GetAxis("Vertical");
        float inputHorizontal = Input.GetAxis("Horizontal");

        if(transform.position.z < -zLimit)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, -zLimit);
        }
        else if(transform.position.z > zLimit)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, zLimit);
        }
        else
        {
            transform.Translate(Vector3.forward * inputVertical * speed * Time.deltaTime);
        }

        if(transform.position.x < -xLimit)
        {
            transform.position = new Vector3(-xLimit, transform.position.y, transform.position.z);
        }
        else if(transform.position.x > xLimit)
        {
            transform.position = new Vector3(xLimit, transform.position.y, transform.position.z);
        }
        else
        {
            transform.Translate(Vector3.right * inputHorizontal * speed * Time.deltaTime);
        }
    }
}
